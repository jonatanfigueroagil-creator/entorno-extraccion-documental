"""Resumen de la bandeja de pólizas del equipo DEMO.

Lee cada PDF de la bandeja, toma su texto (con OCR si el PDF es una imagen) y deja resumen.csv con el archivo,
los caracteres y la primera línea. En la máquina del autor funcionaba.
"""
import csv
import io
import os
from pathlib import Path

import pymupdf
import pytesseract
from PIL import Image
from unidecode import unidecode

CARPETA = Path(r"C:\curso\autor\proyecto_demo\bandeja")
pytesseract.pytesseract.tesseract_cmd = r"C:\curso\autor\programas\Tesseract-OCR\tesseract.exe"
MINIMO = int(os.environ["MINIMO_CARACTERES"])


def leer(ruta):
    """Texto del PDF; si tiene menos de MINIMO caracteres, OCR de la primera página."""
    with pymupdf.open(ruta) as pdf:
        texto = "\n".join(pagina.get_text() for pagina in pdf)
        if len(texto.strip()) < MINIMO:
            imagen = Image.open(io.BytesIO(pdf[0].get_pixmap(dpi=200).tobytes("png")))
            texto = pytesseract.image_to_string(imagen, lang="spa")
    return texto


filas = []
for ruta in sorted(CARPETA.glob("*.pdf")):
    texto = leer(ruta)
    primera = next((linea for linea in texto.splitlines() if linea.strip()), "")
    filas.append({"archivo": ruta.name, "caracteres": len(texto), "primera_linea": unidecode(primera)})
with open("resumen.csv", "w", newline="", encoding="utf-8") as archivo:
    escritor = csv.DictWriter(archivo, fieldnames=["archivo", "caracteres", "primera_linea"])
    escritor.writeheader()
    escritor.writerows(filas)
print(f"Listo: {len(filas)} documentos en resumen.csv")
